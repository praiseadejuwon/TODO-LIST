<template>
  <div class="about">
    <h1>About Page</h1>
    <p>This Is a todo app which is a project part of the vue js crash course on youtube</p>
  </div>
</template>

<style>
.about h1{
  color: black;
  margin-bottom: 10px;
}
.about p{
  color: blue;
}
</style>
