<template>
  <nav>
    <headerLayout/>
  </nav>
  <router-view/>
</template>
<script>
   import headerLayout from './components/layout/headerLayout'

export default {
  name: "App",
  components: {
    headerLayout,
    
}
}
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 10px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>
